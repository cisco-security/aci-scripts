#!/usr/bin/env python


# list of packages that should be imported for this code to work
import cobra.mit.access
import cobra.mit.request
import cobra.mit.session
import cobra.model.fv
import cobra.model.pol
import cobra.model.vns
import sys
from cobra.internal.codec.xmlcodec import toXMLStr

pod_num_start = int(sys.argv[1])
pod_num_end = int(sys.argv[2])

# log into an APIC and create a directory object
ls = cobra.mit.session.LoginSession('https://10.10.35.10', 'pod%s' % pod_num_end, 'cisco')
md = cobra.mit.access.MoDirectory(ls)
md.login()

for pod_num in range(pod_num_start, (1 + pod_num_end)):

    # the top level object on which operations will be made
    polUni = cobra.model.pol.Uni('')
    fvTenant = cobra.model.fv.Tenant(polUni, 'pod%s' % pod_num)

    # build the request using cobra syntax
    vnsDevMgr = cobra.model.vns.DevMgr(fvTenant, ownerKey=u'', name=u'fmc62', descr=u'', ownerTag=u'')
    vnsCCred = cobra.model.vns.CCred(vnsDevMgr, name=u'username', value=u'apiuser')
    vnsCCredSecret = cobra.model.vns.CCredSecret(vnsDevMgr, name=u'password', value=u'cisco')
    vnsCMgmts = cobra.model.vns.CMgmts(vnsDevMgr, host=u'10.10.30.%d' % pod_num, name=u'', port=u'443')
    vnsRsDevMgrToMDevMgr = cobra.model.vns.RsDevMgrToMDevMgr(vnsDevMgr, tDn=u'uni/infra/mDevMgr-CISCO-FTDmgr_FI-1.0')
    

    # commit the generated code to APIC
    print toXMLStr(fvTenant)
    c = cobra.mit.request.ConfigRequest()
    c.addMo(fvTenant)
    md.commit(c)

